function calcularMelhorMomento() {
    return "Esperar até multiplicador acima de 2.0x antes de entrar.";
}
module.exports = { calcularMelhorMomento };